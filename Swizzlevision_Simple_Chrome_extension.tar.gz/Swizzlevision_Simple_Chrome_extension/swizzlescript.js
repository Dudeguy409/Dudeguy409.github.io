function navSwizzleFrame(){
  console.log("Trying to navigate");
  document.getElementById('swizzleframe').src="http://dudeguy409.github.io/";
}
document.getElementById('swizzleswitch').addEventListener("click", navSwizzleFrame);
