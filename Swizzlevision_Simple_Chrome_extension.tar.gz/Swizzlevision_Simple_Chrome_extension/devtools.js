chrome.devtools.panels.create("SwizzleVision",
    null,
    "swizzle.html",
    null
);
chrome.devtools.panels.elements.createSidebarPane("SwizzlePane",
    function(sidebar) {
        sidebar.setPage("swizzle.html");
});
