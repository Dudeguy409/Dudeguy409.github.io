This extension adds a panel to the DevTools window containing an iframe that can
be navigated between two pages and hopefully two processes.  Additionally, this
extension can test unusual types of navigations.  Specifically:

  -about:blank*

  -a data URL

  -back to the extension's prenavigate.html page

  -after navigating the iframe to the web url, navigating it back to a blob or
   filesystem URL should cause a process swap for the iframe.  The URLs are
   logged to console to make them easy to copy and paste into the input field
   for the web iframe.


* Note that after the prenavigate iframe is navigated to the web iframe, a
navigation to "about:blank" would have two separate effects, depending on where
the call comes from.  If it is done by clicking the "about:blank" button in the
web iframe, the new page should remain in the same SiteInstance.  Contrarily, if
the devtools console was used from a parent frame to navigate the web iframe to
about blank, it would swap SiteInstances.
