chrome.devtools.panels.create("Renavigator",
    null,
    "panel.html",
    null
);
// All of the code below is a slightly-adapted copy of code from:
// https://www.html5rocks.com/en/tutorials/file/filesystem/ 
function onInitFs(fs) {
  console.log('Opened file system: ' + fs.name);
  fs.root.getFile('filesystem_test_page.html', {create: true}, function(fileEntry) {
    // Create a FileWriter object for our FileEntry (filesystem_test_page.html).
    fileEntry.createWriter(function(fileWriter) {
      fileWriter.onwriteend = function(e) {
        console.log('Write completed.');
      };
      fileWriter.onerror = function(e) {
        console.log('Write failed: ' + e.toString());
      };
      // Create a new Blob and write it to filesystem_test_page.html.
      var blob = new Blob(['<html><body><h1>filesystem page big</h1><h5>filesystem page small</h5></body></html>'], {type: 'text/html'});
      fileWriter.write(blob);
    }, errorHandler);
    console.log('This is your "filesystem:" URL: ' + fileEntry.toURL());
  }, errorHandler);
}
function errorHandler(e) {
  var msg = '';
  switch (e.code) {
    case FileError.QUOTA_EXCEEDED_ERR:
      msg = 'QUOTA_EXCEEDED_ERR';
      break;
    case FileError.NOT_FOUND_ERR:
      msg = 'NOT_FOUND_ERR';
      break;
    case FileError.SECURITY_ERR:
      msg = 'SECURITY_ERR';
      break;
    case FileError.INVALID_MODIFICATION_ERR:
      msg = 'INVALID_MODIFICATION_ERR';
      break;
    case FileError.INVALID_STATE_ERR:
      msg = 'INVALID_STATE_ERR';
      break;
    default:
      msg = 'Unknown Error';
      break;
  };
  console.log('Error: ' + msg);
}
// Note: The file system has been prefixed as of Google Chrome 12:
window.requestFileSystem  = window.requestFileSystem || window.webkitRequestFileSystem;
window.requestFileSystem(window.TEMPORARY, 5*1024*1024 /*5MB*/, onInitFs, errorHandler);
