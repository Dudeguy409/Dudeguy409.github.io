function navigate(){
  console.log("Trying to navigate");
  window.location.href="http://dudeguy409.github.io/back.html";
}
document.getElementById('forwardSwitch').addEventListener("click", navigate);
var blob = new Blob(['<html><body><h1>blob big</h1><h5>blob small</h5></body></html>'], {type: 'text/html'});
blobURL = URL.createObjectURL(blob);
console.log("This is the url of your blob:"+blobURL);
console.log("This is the url of your prenavigate page: "+location.href);
