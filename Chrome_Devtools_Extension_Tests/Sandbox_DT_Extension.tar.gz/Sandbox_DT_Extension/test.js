alert("This is an alert from test.js, a subframe of the sandboxed DTE");
