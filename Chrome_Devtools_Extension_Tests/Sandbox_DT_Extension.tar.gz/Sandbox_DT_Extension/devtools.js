chrome.devtools.panels.create("Sandbox",
    null,
    "panel.html",
    null
);
