This extension demonstrates sandboxing an iframe in the devtools panel of a
devtools extension.  To compare behavior with and without sandboxing, replace
the iframe in panel.html with either of the uncommented lines.  The sandboxed
iframe has 3 subframes: one to test.html (hence the need to declare it as web
accessible in the manifest), another to a web page, and another that can be
customized to any URL by typing it into the input field.  It was intended that
this URL would reference a web accessible page in another devtools extension.

When the button is clicked, the three iframes are navigated to their
corresponding URLs.

All of these pages are expected to work.
