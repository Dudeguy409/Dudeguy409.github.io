function navFrames(){

  console.log("Trying to navigate");

  document.getElementById('web-frame').src="http://dudeguy409.github.io/";
  document.getElementById('dte-frame').src="/test.html";

  var url = document.getElementById('navinput').value;
  document.getElementById('dte-2-frame').src=url;

}

alert("scripts within sandboxed devtools extension iframes seem to work.");
document.getElementById('navbutton').addEventListener("click", navFrames);
