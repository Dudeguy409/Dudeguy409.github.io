function navSwizzle(){
  document.getElementById('swizzle-frame').src="http://dudeguy409.github.io/";
}
function navEvil(){
  document.getElementById('swizzle-frame').src="http://toastytech.com/evil/";
}
function navMail(){
  document.getElementById('swizzle-frame').src="http://youvegotmail.warnerbros.com/cmp/0frameset.html";
}
function navCustom(){
  var url = document.getElementById('custom-input').value;
  document.getElementById('swizzle-frame').src=url;
}
document.getElementById('swizzle-switch').addEventListener("click", navSwizzle);
document.getElementById('evil-switch').addEventListener("click", navEvil);
document.getElementById('mail-switch').addEventListener("click", navMail);
document.getElementById('custom-switch').addEventListener("click", navCustom);
