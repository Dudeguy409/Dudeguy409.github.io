chrome.devtools.panels.create("SwizzleVision Showcase",
    null,
    "swizzle.html",
    null
);
chrome.devtools.panels.elements.createSidebarPane("SwizzlePane Showcase",
    function(sidebar) {
        sidebar.setPage("swizzle.html");
});
