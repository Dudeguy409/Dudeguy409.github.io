This extension showcases the different features that are possible with devtools
extensions, and shows all of the different locations in a devtools extension
where an iframe can be embedded. Specifically, this extension creates iframes
in the following places:

  - The Devtools Panel

  - The SideBarPane of the "Elements" Panel

  - The Devtools Background page

  - The Extension Background page

  - The Browser Action Popup
