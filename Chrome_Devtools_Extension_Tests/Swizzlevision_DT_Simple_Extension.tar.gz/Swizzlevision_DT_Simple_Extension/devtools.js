chrome.devtools.panels.create("SwizzleVision Simple",
    null,
    "swizzle.html",
    null
);
chrome.devtools.panels.elements.createSidebarPane("SwizzlePane Simple",
    function(sidebar) {
        sidebar.setPage("swizzle.html");
});
