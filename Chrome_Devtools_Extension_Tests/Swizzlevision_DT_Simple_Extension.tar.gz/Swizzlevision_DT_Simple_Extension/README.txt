This extension adds a panel and SideBarPane to the DevTools window containing an
iframe that can be navigated to different URLs.  The purpose of this extension
is to demonstrate that web iframes within devtools extensions are booted
out of process.

Functionality to different websites was added to make it possible to distinguish
between the web iframes in both panels while using the Task Manager (shift+esc).
Similarly, buttons were added to the pages to make it possible to see the exact
moment the web iframes are created/navigated in the Task Manager.

Two separate devtools pages were included, one which contains a web iframe, and
one which doesn't.  This was done to make it easier to see when the web iframes
are being loaded, since the iframe in the devtools page loads automatically.
