This extension adds a panel to the DevTools window containing an iframe that can
be navigated between two pages and hopefully two processes.  Additionally, this
extension can test unusual types of navigations.  Specifically:

  -about:blank*

  -a data URL

  -back to the extension's prenavigate.html page

  -Blob and FileSystem URLs**


* Note that after the prenavigate iframe is navigated to the web iframe, a
navigation to "about:blank" would have two separate effects, depending on where
the call comes from.  If it is done by clicking the "about:blank" button in the
web iframe, the new page should remain in the same SiteInstance.  Contrarily, if
the devtools console was used from a parent frame to navigate the web iframe to
about blank, it would swap SiteInstances.

** After navigating the iframe to the web url, navigating it back to a Blob or
   FileSystem URL should fail.  The blob URL should fail because the document
   has been destroyed, and the FileSystem URL should fail because the URL is not
   a web accessible resource for the extension.  They should both work when
   navigating the iframe to them before navigating the iframe to the web URL.
   The URLs are logged to console to make them easy to test by copying and
   pasting into either the input field on the devtools panel, or the input
   field on the web page.


