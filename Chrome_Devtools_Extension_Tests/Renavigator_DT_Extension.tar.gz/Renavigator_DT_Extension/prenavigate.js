function navigateToWeb(){
  console.log("Trying to navigate");
  window.location.href="http://dudeguy409.github.io/back.html";
}
function navigateToCustomURL(){
  console.log("Trying to navigate");
  var url = document.getElementById('custom-input').value;
  window.location.href=url;
}
document.getElementById('web-button').addEventListener("click", navigateToWeb);
document.getElementById('custom-button').addEventListener("click", navigateToCustomURL);
var blob = new Blob(['<html><body><h1>blob big</h1><h5>blob small</h5></body></html>'], {type: 'text/html'});
blobURL = URL.createObjectURL(blob);
console.log("This is the url of your blob:"+blobURL);
console.log("This is the url of your prenavigate page: "+location.href);
