alert("This is an alert from the Web Accessible Extension test page.");
