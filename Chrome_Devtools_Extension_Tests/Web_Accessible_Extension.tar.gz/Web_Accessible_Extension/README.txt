This extension is for testing that iframes can be navigated to pages in
extensions.  In order to do this, navigate an iframe or webpage to test.html.
The URL for this is chrome-devtools://<extension id>/test.html.  As a devtools
extension, the URL is logged to the console when opening devtools.
Alternatively, the extension id can be found by opening chrome://extensions
and checking the box for "Developer mode".

This extension can be loaded as either a devtools or non-devtools extension.
Copy and rename the appropriate manifest to "manifest.json" in order to switch
between extension types.
