This extension adds a panel to the DevTools window containing a shit ton of
web iframes in order to make sure that TDI is working as expected with devtools
extensions.  The extension can be toggled between two pages: a page with iframes
from duplicate URLs, and a page with iframes from unique URLs.  To toggle
between them, change the .html file referenced in devtools.js and (re)load
the extension.

With both pages, all of the iframes should be grouped into a single
process (separate from the devtools or devtools extension processes).
