chrome.devtools.panels.create("TDI Tester",
    null,
    "duplicate_sites_panel.html",
    null
);
