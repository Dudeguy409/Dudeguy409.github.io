chrome.devtools.panels.create("Devtools API Fail",
    null,
    "panel.html",
    null
);
