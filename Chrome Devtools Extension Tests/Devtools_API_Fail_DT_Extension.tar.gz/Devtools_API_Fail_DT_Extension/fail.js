chrome.devtools.panels.elements.createSidebarPane("FailPane",
    function(sidebar) {
        sidebar.setPage("test.html");
});
