TL;DR:  Even devtools extension iframes in priveleged devtools extension pages
don't have Devtools API access.  To test this, open devtools, then select the
"Devtools API Fail" tab.  Now select the "Elements" tab and look for a
sidebarpane named "FailPane".  It should not exist.


This extension demonstrates where calls to the Devtools APIs currently fail.
At the moment, Devtools API calls seem to only work in the devtools page, the
panel page, or the sidebarpane page, but not in iframes that they contain, even
if those iframes embed other pages of the same devtools extension.  To be clear,
even devtools extension iframes in devtools extension pages with API access do
not have API access.  

Specifically, this extension attempts to add a sidebarpane to the elements panel
in devtools in three locations:

  -A web iframe in the devtools page

  -An iframe in the devtools page to another page in the devtools extension

  -An iframe in the devtools panel to another page in the devtools extension

These three iframes will attempt to add the sidebarpane when they are loaded.
The web iframe and devtools extension iframes in the devtools page are loaded
whenever a devtools window is created.  The devtools panel iframe is only loaded
when the Devtools API Fail panel is selected on the devtools toolbar.

If at any time, a new sidebarpane is created in the Elements panel, that means
that the rules for devtools api access have changed.  This is not
necessarily bad.
